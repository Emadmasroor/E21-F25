# Write your code here :-)
import board
import analogio
import time
import neopixel

pin_a1 = analogio.AnalogIn(board.A1)
pixels = neopixel.NeoPixel(board.NEOPIXEL, 10, auto_write=False)

for j in range(200):
    print("Pin A1 analog read:",pin_a1.value)
    print((pin_a1.value,))
    mapped_brightness = 150
    pixels[3] = (0,mapped_brightness,0)
    pixels.show()
    time.sleep(0.1)
