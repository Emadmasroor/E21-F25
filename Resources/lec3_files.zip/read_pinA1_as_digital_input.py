from adafruit_circuitplayground import cp
import time

for j in range(200):
    print("Pin A1 digital read:",cp.touch_A1)
    print((int(cp.touch_A1),))
    if cp.touch_A1:
        cp.pixels[3] = (0,25,0)
    else:
        cp.pixels[3] = (25,0,0)
    time.sleep(0.1)