import board
import analogio
import time

pin_a1 = analogio.AnalogIn(board.A1)

for j in range(200):
    print("Pin A1 analog read:",pin_a1.value)
    print((pin_a1.value,))
    time.sleep(0.1)
